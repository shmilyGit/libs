#define DENORM_EXP (MIN_EXP - 1)
#include <sysdeps/ieee754/ldbl-96/strtold_l.c>
