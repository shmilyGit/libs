#define LONG_DOUBLE_DENORM_BIAS IEEE854_LONG_DOUBLE_BIAS
#include <sysdeps/ieee754/ldbl-96/printf_fphex.c>
