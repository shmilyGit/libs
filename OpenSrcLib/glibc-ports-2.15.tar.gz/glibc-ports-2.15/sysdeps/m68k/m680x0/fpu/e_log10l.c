#define FUNC __ieee754_log10l
#define FUNC_FINITE __log10l_finite
#include <e_acosl.c>
