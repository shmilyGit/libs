#define FUNC __ieee754_exp10f
#define FUNC_FINITE __exp10f_finite
#include <e_acosf.c>
