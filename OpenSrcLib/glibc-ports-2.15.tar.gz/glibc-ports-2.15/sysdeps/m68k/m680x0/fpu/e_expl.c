#define FUNC __ieee754_expl
#define FUNC_FINITE __expl_finite
#include <e_acosl.c>
