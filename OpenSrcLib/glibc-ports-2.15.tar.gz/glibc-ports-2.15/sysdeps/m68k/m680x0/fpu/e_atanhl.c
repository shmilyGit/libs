#define FUNC __ieee754_atanhl
#define FUNC_FINITE __atanhl_finite
#include <e_acosl.c>
