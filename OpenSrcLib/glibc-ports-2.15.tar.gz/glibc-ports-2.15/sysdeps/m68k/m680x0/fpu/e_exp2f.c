#define FUNC __ieee754_exp2f
#define FUNC_FINITE __exp2f_finite
#include <e_acosf.c>
