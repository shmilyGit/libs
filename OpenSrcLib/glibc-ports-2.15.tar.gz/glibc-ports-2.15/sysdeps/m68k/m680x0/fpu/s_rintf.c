#define	FUNC	rintf
#include <s_atanf.c>
