#define FUNC __ieee754_sqrtf
#define FUNC_FINITE __sqrtf_finite
#include <e_acosf.c>
