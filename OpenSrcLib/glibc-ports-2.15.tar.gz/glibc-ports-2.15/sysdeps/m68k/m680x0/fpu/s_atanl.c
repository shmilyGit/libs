#ifndef FUNC
#define FUNC atanl
#endif
#define float_type long double
#include <s_atan.c>
