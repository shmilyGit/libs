#define FUNC sinl
#include <s_atanl.c>
