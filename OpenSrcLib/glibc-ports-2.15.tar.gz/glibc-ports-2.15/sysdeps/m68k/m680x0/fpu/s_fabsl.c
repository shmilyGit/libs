#define FUNC fabsl
#include <s_atanl.c>
