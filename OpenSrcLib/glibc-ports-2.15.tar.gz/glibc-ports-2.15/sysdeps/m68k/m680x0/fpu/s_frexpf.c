#define FUNC frexpf
#define float_type float
#include <s_frexp.c>
