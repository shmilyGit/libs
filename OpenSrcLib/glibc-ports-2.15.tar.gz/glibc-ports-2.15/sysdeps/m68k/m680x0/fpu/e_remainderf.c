#define FUNC __ieee754_remainderf
#define FUNC_FINITE __remainderf_finite
#include <e_fmodf.c>
