/* Nothing to do.  This function is the same as scalbn.  So we define an
   alias.  */
