#define	FUNC	tanhf
#include <s_atanf.c>
