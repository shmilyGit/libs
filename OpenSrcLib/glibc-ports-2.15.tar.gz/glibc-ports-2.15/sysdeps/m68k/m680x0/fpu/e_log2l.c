#define FUNC __ieee754_log2l
#define FUNC_FINITE __log2l_finite
#include <e_acosl.c>
