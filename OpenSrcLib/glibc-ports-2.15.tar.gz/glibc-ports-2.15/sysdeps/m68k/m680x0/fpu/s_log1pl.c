#define FUNC log1pl
#include <s_atanl.c>
