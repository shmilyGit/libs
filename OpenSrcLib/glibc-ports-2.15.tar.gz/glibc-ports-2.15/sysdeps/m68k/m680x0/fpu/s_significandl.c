#define FUNC significandl
#include <s_atanl.c>
