#define	FUNC truncf
#include <s_atanf.c>
