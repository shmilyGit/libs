#define	FUNC	fabs
#include <s_atan.c>
