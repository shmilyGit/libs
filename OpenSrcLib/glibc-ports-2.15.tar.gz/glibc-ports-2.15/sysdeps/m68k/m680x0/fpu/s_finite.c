#define	FUNC	finite
#include <s_isinf.c>
