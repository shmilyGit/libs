#define	FUNC	finitef
#include <s_isinff.c>
