#define FUNC tanl
#include <s_atanl.c>
