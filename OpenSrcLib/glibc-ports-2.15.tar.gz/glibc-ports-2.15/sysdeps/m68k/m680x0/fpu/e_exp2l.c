#define FUNC __ieee754_exp2l
#define FUNC_FINITE __exp2l_finite
#include <e_acosl.c>
