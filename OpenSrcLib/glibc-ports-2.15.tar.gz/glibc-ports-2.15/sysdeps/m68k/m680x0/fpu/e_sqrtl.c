#define FUNC __ieee754_sqrtl
#define FUNC_FINITE __sqrtl_finite
#include <e_acosl.c>
