#define FUNC __ieee754_sinhl
#define FUNC_FINITE __sinhl_finite
#include <e_acosl.c>
