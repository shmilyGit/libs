#define	FUNC truncl
#include <s_atanl.c>
