#define FUNC __ieee754_atanh
#define FUNC_FINITE __atanh_finite
#include <e_acos.c>
