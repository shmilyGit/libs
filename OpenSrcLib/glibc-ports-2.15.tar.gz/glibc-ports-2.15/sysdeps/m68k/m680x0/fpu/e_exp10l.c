#define FUNC __ieee754_exp10l
#define FUNC_FINITE __exp10l_finite
#include <e_acosl.c>
