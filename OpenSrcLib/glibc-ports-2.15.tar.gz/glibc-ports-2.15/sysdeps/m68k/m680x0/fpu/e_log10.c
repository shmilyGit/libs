#define FUNC __ieee754_log10
#define FUNC_FINITE __log10_finite
#include <e_acos.c>
