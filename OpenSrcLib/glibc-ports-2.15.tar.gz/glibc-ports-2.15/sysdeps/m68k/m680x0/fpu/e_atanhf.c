#define FUNC __ieee754_atanhf
#define	FUNC_FINITE __atanhf_finite
#include <e_acosf.c>
