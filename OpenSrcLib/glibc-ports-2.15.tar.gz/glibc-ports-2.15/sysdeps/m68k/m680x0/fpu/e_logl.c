#define FUNC __ieee754_logl
#define FUNC_FINITE __logl_finite
#include <e_acosl.c>
