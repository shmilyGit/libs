#define FUNC __ieee754_logf
#define FUNC_FINITE __logf_finite
#include <e_acosf.c>
