#define	FUNC	tanf
#include <s_atanf.c>
