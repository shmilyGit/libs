#define FUNC cosl
#include <s_atanl.c>
