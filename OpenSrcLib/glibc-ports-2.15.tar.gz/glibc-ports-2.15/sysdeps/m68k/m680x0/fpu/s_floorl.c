#define FUNC floorl
#include <s_atanl.c>
