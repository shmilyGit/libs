#ifndef FUNC
# define FUNC __ieee754_fmodf
# define FUNC_FINITE __fmodf_finite
#endif
#define float_type float
#include <e_fmod.c>
