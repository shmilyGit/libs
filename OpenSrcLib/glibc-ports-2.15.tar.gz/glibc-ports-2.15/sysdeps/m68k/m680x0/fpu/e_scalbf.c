#define SUFF f
#define float_type float
#include <e_scalb.c>
