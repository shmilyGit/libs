#define FUNC __ieee754_cosh
#define FUNC_FINITE __cosh_finite
#include <e_acos.c>
