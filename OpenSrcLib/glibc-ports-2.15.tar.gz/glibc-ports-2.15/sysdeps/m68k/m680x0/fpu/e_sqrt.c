#define FUNC __ieee754_sqrt
#define FUNC_FINITE __sqrt_finite
#include <e_acos.c>
