#define FUNC tanhl
#include <s_atanl.c>
