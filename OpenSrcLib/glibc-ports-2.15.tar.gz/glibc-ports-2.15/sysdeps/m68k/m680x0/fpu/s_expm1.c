#define	FUNC	expm1
#include <s_atan.c>
