#define FUNC __ieee754_exp2
#define FUNC_FINITE __exp2_finite
#include <e_acos.c>
