#define FUNC __ieee754_log2f
#define FUNC_FINITE __log2f_finite
#include <e_acosf.c>
