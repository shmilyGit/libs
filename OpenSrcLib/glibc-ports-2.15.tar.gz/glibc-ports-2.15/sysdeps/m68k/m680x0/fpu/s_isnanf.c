#define	FUNC	isnanf
#include <s_isinff.c>
