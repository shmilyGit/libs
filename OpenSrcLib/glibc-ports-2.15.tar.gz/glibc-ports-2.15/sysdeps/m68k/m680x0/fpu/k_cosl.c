#define FUNC cosl
#define float_type long double
#include <k_cos.c>
