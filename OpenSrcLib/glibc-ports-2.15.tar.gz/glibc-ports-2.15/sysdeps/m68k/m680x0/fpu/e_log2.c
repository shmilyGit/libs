#define FUNC __ieee754_log2
#define FUNC_FINITE __log2_finite
#include <e_acos.c>
