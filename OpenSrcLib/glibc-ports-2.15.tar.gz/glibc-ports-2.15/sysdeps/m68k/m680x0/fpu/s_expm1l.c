#define FUNC expm1l
#include <s_atanl.c>
libm_hidden_def (__expm1l)
