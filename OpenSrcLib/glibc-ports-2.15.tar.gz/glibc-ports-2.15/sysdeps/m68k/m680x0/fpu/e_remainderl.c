#define FUNC __ieee754_remainderl
#define FUNC_FINITE __remainderl_finite
#include <e_fmodl.c>
