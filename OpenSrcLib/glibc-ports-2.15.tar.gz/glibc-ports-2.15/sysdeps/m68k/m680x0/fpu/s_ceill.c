#define FUNC ceill
#include <s_atanl.c>
