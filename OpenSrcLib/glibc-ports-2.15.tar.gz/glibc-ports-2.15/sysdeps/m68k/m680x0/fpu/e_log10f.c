#define FUNC __ieee754_log10f
#define FUNC_FINITE __log10f_finite
#include <e_acosf.c>
