#define	FUNC	cos
#include <s_atan.c>
