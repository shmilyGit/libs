#define FUNC __ieee754_remainder
#define FUNC_FINITE __remainder_finite
#include <e_fmod.c>
