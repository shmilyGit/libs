#define	FUNC	tan
#include <s_atan.c>
