#define FUNC __ieee754_sinhf
#define FUNC_FINITE __sinhf_finite
#include <e_acosf.c>
