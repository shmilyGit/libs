#define FUNC __ieee754_sinh
#define FUNC_FINITE __sinh_finite
#include <e_acos.c>
