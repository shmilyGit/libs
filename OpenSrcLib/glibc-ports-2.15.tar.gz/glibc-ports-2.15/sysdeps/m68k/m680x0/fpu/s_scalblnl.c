/* Nothing to do.  This function is the same as scalbnl.  So we define an
   alias.  */
