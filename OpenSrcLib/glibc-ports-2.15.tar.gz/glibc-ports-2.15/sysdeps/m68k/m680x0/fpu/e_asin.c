#define	FUNC	__ieee754_asin
#define	FUNC_FINITE __asin_finite
#include <e_acos.c>
