#define	FUNC	significandf
#include <s_atanf.c>
