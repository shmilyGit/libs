#ifndef	FUNC
# define FUNC __ieee754_acosf
# define FUNC_FINITE __acosf_finite
#endif
#define float_type float
#include <e_acos.c>
