#define	FUNC trunc
#include <s_atan.c>
