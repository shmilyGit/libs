#define FUNC __ieee754_log
#define FUNC_FINITE __log_finite
#include <e_acos.c>
