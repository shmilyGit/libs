#define	FUNC	tanh
#include <s_atan.c>
