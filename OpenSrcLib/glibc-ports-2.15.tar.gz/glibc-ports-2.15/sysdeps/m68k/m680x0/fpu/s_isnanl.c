#define FUNC isnanl
#include <s_isinfl.c>
