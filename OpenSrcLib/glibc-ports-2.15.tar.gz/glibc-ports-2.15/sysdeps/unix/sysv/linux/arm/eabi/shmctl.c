#include <sysdeps/unix/sysv/linux/alpha/shmctl.c>
