#include <sysdeps/unix/sysv/linux/alpha/msgctl.c>
