#include <sysdeps/unix/sysv/linux/alpha/semctl.c>
