#include <nptl/sysdeps/unix/sysv/linux/x86_64/timer_settime.c>
