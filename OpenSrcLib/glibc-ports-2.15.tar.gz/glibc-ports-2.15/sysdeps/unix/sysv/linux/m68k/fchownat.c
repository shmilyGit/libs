#include <sysdeps/unix/sysv/linux/i386/fchownat.c>
