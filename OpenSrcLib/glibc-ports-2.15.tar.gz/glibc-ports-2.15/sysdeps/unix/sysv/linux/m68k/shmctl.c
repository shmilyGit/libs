#include <sysdeps/unix/sysv/linux/i386/shmctl.c>
