#include <sysdeps/unix/sysv/linux/i386/oldgetrlimit64.c>
